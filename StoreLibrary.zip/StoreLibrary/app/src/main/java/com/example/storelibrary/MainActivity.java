package com.example.storelibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etEmail, etPass;
    Button btnLogin;
    TextView tvReg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmail = (EditText) findViewById(R.id.email);
        etPass = (EditText) findViewById(R.id.pass);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        tvReg = (TextView) findViewById(R.id.tvReg);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stremail, strpass, stregister;

                stremail = etEmail.getText().toString();
                strpass = etPass.getText().toString();

                if (stremail.equals("priti0011pal@gmail.com") && strpass.equals("1234")) {
                    Intent in = new Intent(MainActivity.this, Main2Activity.class);
                    startActivity(in);
                } else if (stremail.equals("") || strpass.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter Name ana Phone", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Wrong Name and number entered", Toast.LENGTH_SHORT).show();
                }


            }

        });
        tvReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, com.example.storelibrary.RegisterActivity.class);
                startActivity(i);
                finish();

            }
        });


    }
}
