package com.example.storelibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText etEmail,etPass,etName,etConPass;
    Button btnReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etemail);
        etPass = findViewById(R.id.etpass);
        etConPass = findViewById(R.id.etConPass);

        btnReg = findViewById(R.id.btnReg);

        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String  Name,Email,Pass,conPass;

                Name = etName.getText().toString();
                Email = etEmail.getText().toString();
                Pass = etPass.getText().toString();
                conPass = etConPass.getText().toString();

                if (Name.equals(""))
                {
                    Toast.makeText(RegisterActivity.this, "Email Required",Toast.LENGTH_SHORT).show();
                }
                else if(Email.equals("")){
                    Toast.makeText(RegisterActivity.this, "Password Required", Toast.LENGTH_SHORT).show();
                }

                else if (Pass.equals(""))
                {
                    Toast.makeText(RegisterActivity.this, "Email Required",Toast.LENGTH_SHORT).show();
                }
                else if(conPass.equals("")){
                    Toast.makeText(RegisterActivity.this, "Password Required", Toast.LENGTH_SHORT).show();
                }
                else if(conPass.equals("Pass")){
                    Toast.makeText(RegisterActivity.this, "Password Mismatch", Toast.LENGTH_SHORT).show();
                }
                else{
                    //Authetentication
                }

            }
        });
        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(i);
                finish();

            }
        });


    }
}
